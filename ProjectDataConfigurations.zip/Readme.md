
# TechNet December 2018: VB.NET secure connection string

## Introduction

This article describes how to secure connection strings in an application's configuration file for Window forms projects.

Examples
- Working with TableAdapter
- Working with manage data provider


[Article location](https://social.technet.microsoft.com/wiki/contents/articles/52301.secure-connection-string-for-windows-forms-vb-net.aspx)